----------------------------------------------------------------------------------
-- Company: CSUN
-- Engineer: Antonio Anzora Jr
-- 
-- Create Date: 09/07/2026 11:10:06 PM
-- Design Name: 
-- Module Name: rgb_led_TOP_TB - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity rgb_led_TOP_TB is
--  Port ( );
end rgb_led_TOP_TB;

architecture Behavioral of rgb_led_TOP_TB is
component rgb_led_TOP is
  generic(CLK_CYCLES_PER_TOGGLE:integer:= 62500000);
  Port (sys_clk :in std_logic;
        rst:in std_logic;
        --3 bit width for sw and rgb_out 
        sw:in std_logic_vector(2 downto 0);
        rgb_out:out std_logic_vector(2 downto 0)
         );
end component rgb_led_TOP;
signal sys_clk_TB: std_logic;
signal rst_TB:std_logic;
signal sw_TB: std_logic_vector(2 downto 0);
signal rgb_out_TB:std_logic_vector(2 downto 0);

-- constant makes its easier to read. basically a place holder if needed i can change the value. 
-- 8 ns was solved by the given clock frequency which is 125MHz so we find the period to get the clk_period.
constant clk_period:time:= 8 ns;
begin
    UUT:rgb_led_TOP
        generic map(CLK_CYCLES_PER_TOGGLE=>10)
        port map(sys_clk=>sys_clk_TB, rst=>rst_TB, sw=>sw_TB, rgb_out=>rgb_out_TB);
        
    clk_process: process
    begin
        sys_clk_TB <= '0';
        wait for clk_period/2;
        sys_clk_TB<= '1';
        wait for clk_period/2;
    end process;
    
    simulation_process: process
    begin
    --we are considering that all switches are off
        rst_TB<='1';
        sw_TB<="000";
        wait for 40 ns;  
        rst_TB<= '0';
        wait for 40 ns;
        --Only Red
        sw_TB <= "001";
        wait for 40 ns;
        --Only Green
        sw_TB <= "010";
        wait for 40 ns;
        --Only Blue
        sw_TB<= "100";
        wait for 40 ns;
        --Turning all colors such as Red,Green,Blue
        sw_TB<= "111";
        wait for 40 ns;
        --Reseting the whole thing (off)
        sw_TB <= "000";
        wait for 40 ns;
        wait;
    end process;  
       
end Behavioral;
