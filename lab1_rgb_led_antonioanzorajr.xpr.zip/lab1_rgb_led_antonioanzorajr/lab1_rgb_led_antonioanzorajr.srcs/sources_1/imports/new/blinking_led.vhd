----------------------------------------------------------------------------------
-- Company: CSUN - Student
-- Engineer: Antonio Anzora Jr
-- 
-- Create Date: 08/31/2026 05:11:11 PM
-- Design Name: LED BLINK
-- Module Name: blinking_led - Behavioral
-- Project Name: blink_that_led
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity blinking_led is
    -- generic is just a configurable constant that can be changed.
    -- CLK_CYCLES_PER_TOGGLE will tell the circuit how many clock ticks there are to count before toggling the LED.
    
    generic (CLK_CYCLES_PER_TOGGLE : integer := 62500000);
    --Clock must be set at 125MHz, Reset is Active High Synchronous, 
  Port(sys_clk, rst, led_en: in std_logic;
    --LED output driver to LED0
        led_out:out std_logic
      );
end blinking_led;

architecture Behavioral of blinking_led is
    -- this counts upt by 1 on every signal clock tick (rising edge)
    -- once it reachches CLK_CYCLES_PER_TOGGLE we know that 0.5 seconds have passed, so then we toggle the LED  and reset it 0.
    -- range 0 to CLK_CYCLES_PER_TOGGLE - 1 this tells VHDL the max value
    -- ":= 0 " just means that it starts at 0 when the FPGA first powers on
    signal count_reg: integer range 0 to CLK_CYCLES_PER_TOGGLE - 1:=0;
    signal led_reg: std_logic:= '0';
begin
    led_out <=led_reg;
    --  we first check rst first before anything else.
    process(rst,sys_clk)
    begin
        if rst = '1' then
            count_reg <=0;
            led_reg <= '0';
        elsif rising_edge(sys_clk) then
            --Checking for the rising edge
            if led_en = '0' then
                count_reg <= 0;
                led_reg <= '0';
            elsif count_reg = CLK_CYCLES_PER_TOGGLE - 1 then
                count_reg <=0;
                --toggling the led_reg
                led_reg <= not led_reg;
            else 
                count_reg <= count_reg +1;
            end if;
        end if;
     end process;
end Behavioral;