----------------------------------------------------------------------------------
-- Company: CSUN    
-- Engineer: Antonio Anzora Jr
-- 
-- Create Date: 09/07/2026 10:27:27 PM
-- Design Name: 
-- Module Name: rgb_led_TOP - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity rgb_led_TOP is
    generic (CLK_CYCLES_PER_TOGGLE: integer:=62500000);
  Port (sys_clk :in std_logic;
        rst:in std_logic;
        --3 bit width for sw and rgb_out 
        sw:in std_logic_vector(2 downto 0);
        rgb_out:out std_logic_vector(2 downto 0)
         );
end rgb_led_TOP;

architecture Behavioral of rgb_led_TOP is
-- this is the instantiation. Copied the rgb_led vhd file but it will not affect my other file.
component blinking_led is
    -- generic is just a configurable constant that can be changed.
    -- CLK_CYCLES_PER_TOGGLE will tell the circuit how many clock ticks there are to count before toggling the LED.
    generic (CLK_CYCLES_PER_TOGGLE : integer := 62500000);
    --Clock must be set at 125MHz, Reset is Active High Synchronous, 
  Port(sys_clk, rst, led_en: in std_logic;
    --LED output driver to LED0
        led_out:out std_logic
      );
end component blinking_led;

-- Add the signals name for different colors such as red, green, blue and off.
signal RGB_RED: std_logic; -- rgb_out[0]  SW0
signal RGB_GREEN: std_logic; --rgb_out[1] SW1
signal RGB_BLUE: std_logic; --rgb_out[2]  SW2

begin
    LED_RED:blinking_led
        port map(sys_clk=>sys_clk,rst=>rst, led_en =>sw(0),led_out=>RGB_RED);
     
     LED_BLUE:blinking_led
        port map(sys_clk=>sys_clk,rst=>rst, led_en =>sw(2),led_out =>RGB_BLUE);
     
     LED_GREEN:blinking_led
        port map(sys_clk=>sys_clk,rst=>rst, led_en=>sw(1), led_out=>RGB_GREEN);
     -- this is where the wiring happens to the output port. 
     rgb_out(0) <= RGB_RED;
     rgb_out(1) <= RGB_BLUE;
     rgb_out(2) <= RGB_GREEN;
end Behavioral;
